// JavaScript Document

// carbon meter

 function readMeter(){  // updates the box below the slider with the value of the slider 
		
					meter = document.getElementById('carbonM').range.value; // create variable meter by reading value from slider
					document.getElementById('carbonM').meterValue.value = meter; // write the slider value to the input box below slider
									
									
					if (meter <= 100 && meter >= 76){
						document.getElementById("meter").src = "bootstrap/assets/img/100-carbon-meter.png"; // change the image
							}
					else if(meter <= 75 && meter >= 51){
						document.getElementById("meter").src = "bootstrap/assets/img/75-carbon-meter.png"; // change the image
							}
					else if(meter <= 50 && meter >= 26){
						document.getElementById("meter").src = "bootstrap/assets/img/50-carbon-meter.png"; // change the image
							}	
					else if(meter <= 25 && meter >= 1){
						document.getElementById("meter").src = "bootstrap/assets/img/25-carbon-meter.png"; // change the image
							}		
					else if(meter <= 24 && meter >= 0){
						document.getElementById("meter").src = "bootstrap/assets/img/0-carbon-meter.png"; // change the image
							}		
					else
						document.getElementById("meter").src = "bootstrap/assets/img/out-carbon-meter.png"; // change the image
									
							};
									
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////									
									
									